


<?php $__env->startSection('title', 'Detail Articles - Admin'); ?>
    
<?php $__env->startSection('content'); ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mb-5">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"> Detail Article</h1>
    </div>

    <div class="mt-3">
        <table class="table table-striped table-bordered" >
            <tr>
                <th width="250px">Title</th>
                <td><?php echo e($article->title); ?></td>
            </tr>
            <tr>
                <th>Category</th>
                <td><?php echo e($article->Category->name); ?></td>
            </tr>
            <tr>
                <th>Description</th>
                <td><?php echo $article->desc; ?></td>
            </tr>
            <tr>
                <th>Image</th>
                <td>
                    <a href="<?php echo e(asset('storage/back/'. $article->img)); ?>" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('storage/back/'. $article->img)); ?>" alt="" width="30%">
                    </a>
                </td>
            </tr>
            <tr>
                <th>Views</th>
                <td><?php echo e($article->views); ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <?php if($article->status == 1): ?>
                    <td>: <span class="badge bg-success">Published</span></td>
                <?php else: ?>
                    <td>: <span class="badge bg-danger">Private</span></td>
                <?php endif; ?>
            </tr>
            <tr>
                <th>Publish Date</th>
                <td><?php echo e($article->publish_date); ?></td>
            </tr>
            <tr>
                <th>Writers</th>
                <td><?php echo e($article->user->name); ?></td>
            </tr>
        </table>
        <div class="float-end">
            <a href="<?php echo e(url ('article')); ?>" class="btn btn-secondary">Back</a>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\blog\resources\views/back/article/show.blade.php ENDPATH**/ ?>