<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('front/img/logo-web.png')); ?>" alt="logo" class="img-fluid" width="40%">
        </a>
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>" style="font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif">
            
            
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/articles')); ?>">Articles</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Categories
                    </a>
                    <ul class="dropdown-menu">

                        <?php $__currentLoopData = $category_navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item" href="<?php echo e(url('category/'.$item->slug)); ?>"><?php echo e($item->name); ?>

                            </a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    </ul>
                  </li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/about')); ?>">About</a></li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\project\blog\resources\views/front/layout/navbar.blade.php ENDPATH**/ ?>