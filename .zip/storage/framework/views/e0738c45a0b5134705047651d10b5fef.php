

<?php $__env->startSection('title', $article->title. '-NEWS JAMBI'); ?>

<?php $__env->startSection('content'); ?>
            <!-- Tampil Detail Artikel-->
            <div class="container">
                <div class="row">
                    <div class="col-lg-8" data-aos="fade-up">
                        <div class="card mb-4">
                            <a href="<?php echo e(url('p/' .$article->slug)); ?>">
                                <img class="card-img-top single-img" src=" <?php echo e(asset('storage/back/'.$article->img)); ?>" alt="<?php echo e($article->title); ?>" />
                            </a>
                            <div class="card-body">
                                <div class="small text-muted"> 
                                        <span class="ml-2"><?php echo e(asset($article->created_at->format('d-m-Y') )); ?></span>
                                        | <span><?php echo e($article->user->name); ?></span>
                                        | <span class="ml-2">
                                            <a href="<?php echo e(url('category/' .$article->Category->slug)); ?>"><?php echo e($article->Category->name); ?></a>
                                        </span>
                                </div>
                                  
                                <h1 class="card-title"><?php echo e($article->title); ?></h1>
                                <p class="card-text">
                                    <?php echo ($article->desc); ?>

                                </p>

                                <div class="mt-5">
                                    <p style="font-size: 20px"><b>Share This</b></p>

                                    <a href="https://www.facebook.com/sharer.php?u=<?php echo e(url()->current()); ?>"
                                         class="btn btn-primary" target="_blank"><i class="fab fa-facebook"></i> Facebook</a>
                                    <a href="https://api.whatsapp.com/send?text=<?php echo e(url()->current()); ?>" 
                                        class="btn btn-success" target="_blank" ><i class="fab fa-whatsapp"></i> WhatsApp</a>
                                </div>

                            </div>
                        </div>

                    </div>
                    <!-- Side widgets-->
                    <?php echo $__env->make('front.layout.side-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <!-- Footer-->
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\blog\resources\views/front/article/show.blade.php ENDPATH**/ ?>