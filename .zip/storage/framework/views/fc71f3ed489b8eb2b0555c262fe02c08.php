<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="Rizki" />
        <?php echo $__env->yieldPushContent('meta-seo'); ?>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('front/img/favicon.ico')); ?>" >
        <!-- Core theme CSS (includes Bootstrap)-->
        <link rel="stylesheet" href="<?php echo e(asset('front/css/styles.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('front/css/custom.css')); ?>">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
        <?php echo $__env->yieldPushContent('css'); ?>
    </head>
    <body>
        <div class="min-vh-100 d-flex flex-column justify-content-between">
            <!-- Responsive navbar-->
        <?php echo $__env->make('front.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Page header with logo and tagline-->
        <header class="py-5 bg-light border-bottom mb-2">
            <div class="container">
                <div class="text-center my-3">
                    <h1 class="fw-bolder" style="font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif"><?php echo e($config['title']); ?></h1>
                </div>
            </div>
        </header>
        <div class="mb-4 container">
            <div class="row">
                <div class="col-3"></div>
                
                <div class="col-3"></div>
            </div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
        <div class="mb-4 container">
            <div class="row">
                <div class="col-3"></div>
                <div class="col-6">
                    
                </div>
                <div class="col-3"></div>
            </div>
        </div>

        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">
                Copyright &copy; <?php echo e($config['footer']); ?> <?php echo e(date('Y')); ?></p></div>
        </footer>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo e(asset('front/js/scripts.js')); ?>"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>
            AOS.init();
        </script>
        <?php echo $__env->yieldPushContent('js'); ?>

    </body>
</html>

<?php /**PATH D:\project\blog\resources\views/front/layout/template-article.blade.php ENDPATH**/ ?>