

<?php $__env->startSection('title',  'PROJECT AKHIR'); ?>

<?php $__env->startSection('content'); ?>
            <!-- Page content-->
            <div class="container">
                <div class="row">
                    <!-- Blog entries-->
                    <div class="col-lg-8">
                        <!-- Featured blog post-->
                        <div class="card mb-4 shadow">
                            <a href="<?php echo e(asset('front/img/pngegg.png')); ?>">
                                <img class="card-img-top featured-img" src="<?php echo e(asset('front/img/logo-web.png')); ?>" alt="About Laravel Blog" />
                            </a>
                            <div class="card-body">
                                <div class="small text-muted"><?php echo e(date('d/m/Y')); ?> </div>
                                <h2 class="card-title">About NEWS-JAMBI</h2>
                                <p class="card-text">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore 
                                    hic eligendi ducimus, temporibus sint, quod quasi eaque ipsum recusandae 
                                    dolor minima cumque nobis dolorem nemo odit quia harum. Explicabo, veniam.
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore 

                                    hic eligendi ducimus, temporibus sint, quod quasi eaque ipsum recusandae 
                                    dolor minima cumque nobis dolorem nemo odit quia harum. Explicabo, veniam.
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore 

                                    hic eligendi ducimus, temporibus sint, quod quasi eaque ipsum recusandae 
                                    dolor minima cumque nobis dolorem nemo odit quia harum. Explicabo, veniam.
                                    hic eligendi ducimus, temporibus sint, quod quasi eaque ipsum recusandae 
                                    dolor minima cumque nobis dolorem nemo odit quia harum. Explicabo, veniam.
                                    hic eligendi ducimus, temporibus sint, quod quasi eaque ipsum recusandae 
                                    dolor minima cumque nobis dolorem nemo odit quia harum. Explicabo, veniam.
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Side widgets-->
                    <?php echo $__env->make('front.layout.side-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <!-- Footer-->
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\blog\resources\views/front/home/about.blade.php ENDPATH**/ ?>