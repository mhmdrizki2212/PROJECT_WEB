<div class="col-lg-4" data-aos="fade-left">
    <!-- Search widget-->
    <div class="card mb-4">
        <div class="card-header">Search</div>
        <div class="card-body">
           <form action="<?php echo e(route('search')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <input class="form-control" type="text" name="keyword" placeholder="Search Article..." />
                <button class="btn btn-primary" id="button-search" type="submit">Cari</button>
            </div>
           </form>
        </div>
    </div>
    <!-- Categories widget-->
    <div class="card mb-4 shadow-sm">
        <div class="card-header">Categories</div>
        <div class="card-body">
            <div>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span ><a href="<?php echo e(url('category/'.$item->slug)); ?>" class="bg-primary badge text-white unstyle-category">
                    <?php echo e($item->name); ?> (<?php echo e($item->articles_count); ?>)</a></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>             
    </div>
    <!-- Side widget-->
    <div class="card mb-4 shadow-sm">
        <div class="card-header">Side Widget</div>
        <div class="card-body">
            <a href="https://domainesia.com" target="_blank" rel="noopener noreferrer">
                <img src="<?php echo e($config['ads_widget']); ?>" alt="ads_widget" class="img-fluid" width="100%">
            </a>
        </div>
    </div>
    
    <div class="card mb-4 shadow-sm">
        <div class="card-header">Popular Post</div>
        <div class="card-body"></div>
            <?php $__currentLoopData = $popular_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-4">
                    <div class="row">
                        <div class="col-md-3">
                            <img src="<?php echo e(asset('storage/back/' .$item->img)); ?>" alt="<?php echo e($item->title); ?>" class="img-fluid">
                        </div>

                        <div class="col-md-9">
                           <div class="card-body">
                            <p class="card-title">
                                <a href=" <?php echo e(url('p/' .$item->slug)); ?> "  style="text-decoration: none"><?php echo e($item->title); ?></a>
                            </p>
                           </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH D:\project\blog\resources\views/front/layout/side-widget.blade.php ENDPATH**/ ?>