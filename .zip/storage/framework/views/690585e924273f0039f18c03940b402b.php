

<?php $__env->startSection('title', 'NEWS-JAMBI'); ?>

<?php $__env->startSection('content'); ?>
            <!-- Page content-->
            <div class="container">
                <div class="row">
                    <!-- Blog entries-->
                    <div class="col-lg-8">
                        <!-- Featured blog post-->
                        <div class="card mb-4 shadow" data-aos="fade-in">
                            <a href="<?php echo e(url('p/' .$latest_post->slug)); ?>">
                                <img class="card-img-top featured-img" src=" <?php echo e(asset('storage/back/'.$latest_post->img)); ?>" alt="..." />
                            </a>
                            <div class="card-body">
                                <div class="small text-muted"> 
                                    <?php echo e(asset($latest_post->created_at->format('d-m-Y'))); ?>

                                    | <?php echo e($latest_post->user->name); ?>

                                    | <a href="<?php echo e(url('category/'. $latest_post->Category->slug)); ?>"> <?php echo e(asset($latest_post->Category->name)); ?></a>
                                </div>
                                  
                                <h2 class="card-title"><?php echo e($latest_post->title); ?></h2>
                                <p class="card-text">
                                    <?php echo Str::limit(strip_tags($latest_post->desc), 310, '...'); ?>

                                </p>
                                <a class="btn btn-primary" href="<?php echo e(url('p/' .$latest_post->slug)); ?>">Read more →</a>
                            </div>
                        </div>
                        <!-- Nested row for non-featured blog posts-->
                        <div class="row">
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6" data-aos="fade-up">
                                <!-- Blog post-->
                                <div class="card  mb-4 shadow-sm">
                                    <a href="<?php echo e(url('p/' .$item->slug)); ?>"><img class="card-img-top post-img" src="<?php echo e(asset('storage/back/'.$item->img)); ?>" alt="..." /></a>
                                    <div class="card-body card-height">
                                        <div class="small text-muted"> 
                                            <?php echo e(asset($item->created_at->format('d-m-y'))); ?>

                                         |  <?php echo e($item->user->name); ?>

                                         |   <a href="<?php echo e(url('category/'. $item->Category->slug)); ?>"><?php echo e(asset( $item->category->name )); ?></a>
                                        </div>
                                        <h2 class="card-title h4"> <?php echo e($item->title); ?> </h2>
                                        <p class="card-text">
                                            <?php echo Str::limit(strip_tags($item->desc), 250, '...'); ?>


                                        </p>
                                        <a class="btn btn-primary" href="<?php echo e(url('p/' .$item->slug)); ?>">Read more →</a>
                                    </div>
                                </div>
                                <!-- Blog post-->
                            </div>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        
                        <div class="pagination justify-content-center my-4">
                            <?php echo e($articles->links()); ?>

                        </div>

                    </div>
                    <!-- Side widgets-->
                    <?php echo $__env->make('front.layout.side-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <!-- Footer-->
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\blog\resources\views/front/home/index.blade.php ENDPATH**/ ?>